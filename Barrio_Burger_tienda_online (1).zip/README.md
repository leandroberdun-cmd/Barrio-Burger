# Barrio Burger — Mi tienda online

## Descripción
Barrio Burger es una tienda online ficticia de comida rápida. Permite explorar un menú, buscar y filtrar productos, agregarlos al carrito, cambiar cantidades, eliminarlos y ver el total de la compra.

## Tecnologías
- **HTML:** estructura y contenido.
- **CSS:** diseño visual adaptable a computadora y celular.
- **JavaScript:** filtros, búsqueda, carrito, mensajes y simulación de compra.
- **localStorage:** guarda el carrito aunque se actualice la página.

## Funcionalidades
- Catálogo con imagen, nombre, categoría, descripción y precio.
- Filtro por categorías y buscador.
- Carrito con cantidades editables y opción para eliminar productos.
- Cálculo automático del total.
- Mensajes de confirmación.
- Funcionalidades opcionales: modo responsive, carrito guardado con localStorage y simulación de compra.

## Cómo utilizarla
1. Abrir `index.html` en un navegador.
2. Elegir una categoría o buscar un producto.
3. Presionar el botón `+` para agregarlo al carrito.
4. Abrir “Mi pedido” para cambiar cantidades o eliminar productos.
5. Presionar “Finalizar pedido” para probar la simulación.

## Uso de inteligencia artificial
Se utilizó IA como apoyo para proponer la identidad visual, generar una primera versión del código HTML, CSS y JavaScript, organizar las funciones y detectar posibles errores. El código debe ser revisado y comprendido por los integrantes del grupo.

## Publicar en GitHub Pages
1. Crear un repositorio nuevo en GitHub, por ejemplo `mi-tienda-online`.
2. Subir `index.html`, `styles.css`, `script.js` y `README.md` a la raíz del repositorio.
3. Ir a **Settings → Pages**.
4. En **Build and deployment**, elegir **Deploy from a branch**.
5. Seleccionar la rama `main` y la carpeta `/ (root)`, y guardar.
6. Esperar a que GitHub Pages publique el sitio. El enlace aparecerá en esa misma sección.

## Datos del proyecto
- Nombre: Barrio Burger
- Tipo de tienda: comida rápida
- Proyecto escolar: Mi tienda online
