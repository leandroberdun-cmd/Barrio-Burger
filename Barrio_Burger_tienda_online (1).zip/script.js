const products = [
  {id:1,name:"La Clásica",category:"Hamburguesas",price:8500,description:"Carne, cheddar, lechuga, tomate y salsa de la casa.",image:"https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=700&auto=format&fit=crop"},
  {id:2,name:"Doble Barrio",category:"Hamburguesas",price:11000,description:"Doble carne, doble cheddar y cebolla caramelizada.",image:"https://images.unsplash.com/photo-1553979459-d2229ba7433a?w=700&auto=format&fit=crop"},
  {id:3,name:"Crispy Chicken",category:"Hamburguesas",price:9500,description:"Pollo crocante, lechuga fresca y aderezo especial.",image:"https://images.unsplash.com/photo-1606755962773-d324e0a13086?w=700&auto=format&fit=crop"},
  {id:4,name:"Papas clásicas",category:"Papas",price:4500,description:"Papas doradas con un toque de sal.",image:"https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=700&auto=format&fit=crop"},
  {id:5,name:"Papas cheddar",category:"Papas",price:6500,description:"Papas fritas con cheddar y verdeo.",image:"https://images.unsplash.com/photo-1518013431117-eb1465fa5752?w=700&auto=format&fit=crop"},
  {id:6,name:"Combo Doble",category:"Combos",price:14500,description:"Doble Barrio, papas clásicas y bebida.",image:"https://images.unsplash.com/photo- burger-combo?w=700"},
  {id:7,name:"Combo Clásico",category:"Combos",price:12000,description:"La Clásica, papas chicas y bebida.",image:"https://images.unsplash.com/photo-1550547660-d9450f859349?w=700&auto=format&fit=crop"},
  {id:8,name:"Gaseosa",category:"Bebidas",price:2500,description:"Bebida fría de 500 ml.",image:"https://images.unsplash.com/photo-1581636625402-29b2a704ef13?w=700&auto=format&fit=crop"}
];
// Corregimos una imagen de ejemplo para que la tarjeta del combo tenga una foto válida.
products[5].image = "https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=700&auto=format&fit=crop";

let cart = JSON.parse(localStorage.getItem("barrioBurgerCart") || "[]");
let activeCategory = "Todos";
const grid = document.getElementById("productGrid");
const cartPanel = document.getElementById("cartPanel");
const overlay = document.getElementById("overlay");
const money = value => "$" + value.toLocaleString("es-AR");

function renderProducts(){
  const term = document.getElementById("searchInput").value.toLowerCase().trim();
  const filtered = products.filter(p => (activeCategory === "Todos" || p.category === activeCategory) && (p.name.toLowerCase().includes(term) || p.description.toLowerCase().includes(term)));
  grid.innerHTML = filtered.length ? filtered.map(p => `
    <article class="product-card">
      <div class="product-image"><img src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=700&auto=format&fit=crop'"></div>
      <div class="product-info"><span class="product-category">${p.category}</span><h3>${p.name}</h3><p>${p.description}</p>
        <div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add-btn" onclick="addToCart(${p.id})" aria-label="Agregar ${p.name}">+</button></div>
      </div>
    </article>`).join("") : '<p>No encontramos productos con esa búsqueda.</p>';
}
function saveCart(){localStorage.setItem("barrioBurgerCart",JSON.stringify(cart));renderCart();}
function addToCart(id){const item=cart.find(x=>x.id===id);item?item.qty++:cart.push({id,qty:1});saveCart();showToast("¡Producto agregado al pedido!");}
function changeQty(id,amount){const item=cart.find(x=>x.id===id);if(!item)return;item.qty+=amount;if(item.qty<=0)cart=cart.filter(x=>x.id!==id);saveCart();}
function removeItem(id){cart=cart.filter(x=>x.id!==id);saveCart();showToast("Producto eliminado.");}
function renderCart(){
  const count=cart.reduce((sum,item)=>sum+item.qty,0);
  document.getElementById("cartCount").textContent=count;
  const total=cart.reduce((sum,item)=>{const p=products.find(x=>x.id===item.id);return sum+(p?p.price*item.qty:0)},0);
  document.getElementById("cartTotal").textContent=money(total);
  document.getElementById("cartItems").innerHTML=cart.length?cart.map(item=>{const p=products.find(x=>x.id===item.id);return `<div class="cart-row"><div><h4>${p.name}</h4><small>${money(p.price)} c/u</small><button class="remove-btn" onclick="removeItem(${p.id})">Eliminar</button></div><div class="quantity"><button onclick="changeQty(${p.id},-1)">−</button><b>${item.qty}</b><button onclick="changeQty(${p.id},1)">+</button></div></div>`}).join(""):'<p class="empty-cart">Todavía no agregaste productos.</p>';
}
function openCart(){cartPanel.classList.add("open");overlay.classList.add("show");cartPanel.setAttribute("aria-hidden","false");}
function closeCart(){cartPanel.classList.remove("open");overlay.classList.remove("show");cartPanel.setAttribute("aria-hidden","true");}
let toastTimer;
function showToast(message){const toast=document.getElementById("toast");toast.textContent=message;toast.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove("show"),2300);}

document.getElementById("categories").addEventListener("click",e=>{const btn=e.target.closest("[data-category]");if(!btn)return;activeCategory=btn.dataset.category;document.querySelectorAll(".category").forEach(b=>b.classList.toggle("active",b===btn));renderProducts();});
document.getElementById("searchInput").addEventListener("input",renderProducts);
document.getElementById("cartOpen").addEventListener("click",openCart);
document.getElementById("cartClose").addEventListener("click",closeCart);
overlay.addEventListener("click",closeCart);
document.getElementById("checkoutBtn").addEventListener("click",()=>{if(!cart.length){showToast("Primero agregá algún producto.");return;}const total=cart.reduce((sum,item)=>sum+products.find(p=>p.id===item.id).price*item.qty,0);alert("¡Pedido realizado!\nTotal: "+money(total)+"\nEsta es una simulación escolar, no se realizó ningún pago.");cart=[];saveCart();closeCart();showToast("¡Gracias por elegir Barrio Burger!");});
document.getElementById("contactForm").addEventListener("submit",e=>{e.preventDefault();showToast("¡Gracias! Tu mensaje fue enviado (simulación).");e.target.reset();});
renderProducts();renderCart();